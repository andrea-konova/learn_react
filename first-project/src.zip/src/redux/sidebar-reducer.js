let initialState = {
  friends: [
    {id: 1, name: 'Dimych'},
    {id: 2, name: 'Andrew'},
    {id: 3, name: 'Anna'},
    {id: 4, name: 'Tima'},
    {id: 5, name: 'Sasha'},
    {id: 6, name: 'Vika'}
  ]
};

const sidebarReducer = (state = initialState, action) => {

  return state;
};

export default sidebarReducer;