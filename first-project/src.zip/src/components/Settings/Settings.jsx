import React from 'react';
import classes from './Settings.module.css';

const Settings = (props) => {
  return (
    <div className={classes.item}>
      Settings
    </div>
  );
}

export default Settings;