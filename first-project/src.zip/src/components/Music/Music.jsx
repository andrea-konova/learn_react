import React from 'react';
import classes from './Music.module.css';

const Music = (props) => {
  return (
    <div className={classes.item}>
      Music
    </div>
  );
}

export default Music;