import React from 'react';
import classes from './Login.module.css';

const Login = (props) => {
  return (
    <div className={classes.item}>
      Login
    </div>
  );
}

export default Login;